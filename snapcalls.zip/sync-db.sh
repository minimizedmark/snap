#!/bin/bash
export DATABASE_URL="postgresql://postgres:nJoOBYXnG2psS3FL@db.cukjihbwuqknynsagzkc.supabase.co:5432/postgres"
npx prisma db push
